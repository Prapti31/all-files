package com.example.pwcmsempclient;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PwcMsEmpclientApplicationTests {

	@Test
	void contextLoads() {
	}

}
