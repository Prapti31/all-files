/**
 * 
 */
package com.service;

 
public interface TransferService {
	
	 
	void transferFunds(String fromAccount, String destAccount, double amount);

}
