import '../Main.css'

function Mainpage(){
    return (
        <div className="container-fluid">

            <center>
            <div id="div-container1">Welcome to JobSpace</div>
            
            <br/>
                
            <div className="container">
                <a href="/login" button type="button" className="btn btn-success">Login</a>
                
                <a href="/register" button type="button" className="btn btn-success">Register</a>
            </div>
            <br/>
            <br/>
            <div>
            <footer>
                <p><h5>Copyrights reversed to Hands Company and Co. <sup>&copy;</sup> </h5></p>
            </footer>
            </div>
            </center>
        </div>
    )
}
export default Mainpage;