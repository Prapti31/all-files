const NotFound = () => {
    return (
        <div>
            <p>The page you are looking is not yet developed.</p>
        </div>
    );
}
 
export default NotFound;