

function UserProfile(){

    return(
        <div>Welcome to ur profile</div>
    )
}
export default UserProfile